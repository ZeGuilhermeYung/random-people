export type Error = {
  type: string;
  message: string;
}